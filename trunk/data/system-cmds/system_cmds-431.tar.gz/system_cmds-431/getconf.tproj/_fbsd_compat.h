#define __FBSDID(x)
#ifdef __ppc__
#define __powerpc__
#endif /* __ppc__ */
