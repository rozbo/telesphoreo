require 'msf/ui/gtk2/console/skeleton.rb'
require 'msf/ui/gtk2/console/console.rb'