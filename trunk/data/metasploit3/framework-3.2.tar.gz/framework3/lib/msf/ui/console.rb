module Msf
module Ui
module Console


end
end
end

require 'msf/ui/console/driver'
