#!/usr/bin/env ruby

require 'rex/encoding/xor/generic'

module Rex
module Encoding
module Xor

class Byte < Generic

	def Byte.keysize
		1
	end

end end end end # Byte/Xor/Encoding/Rex
