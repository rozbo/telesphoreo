#!/usr/bin/env ruby

# $Id: image_source.rb 5413 2008-02-13 02:43:56Z ramon $

module Rex
module ImageSource

end
end

require 'rex/image_source/disk'
require 'rex/image_source/memory'