require 'rex/proto/http'
require 'rex/proto/smb'
require 'rex/proto/dcerpc'

module Rex
module Proto

attr_accessor :alias

end
end
