require 'rex/payloads/win32/common'
require 'rex/payloads/win32/kernel'
