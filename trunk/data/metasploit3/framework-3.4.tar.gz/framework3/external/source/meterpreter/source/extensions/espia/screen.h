#ifndef _METERPRETER_SOURCE_EXTENSION_ESPIA_ESPIA_SERVER_SCREEN_H
#define _METERPRETER_SOURCE_EXTENSION_ESPIA_ESPIA_SERVER_SCREEN_H

DWORD request_image_get_dev_screen(Remote *remote, Packet *packet);

#endif