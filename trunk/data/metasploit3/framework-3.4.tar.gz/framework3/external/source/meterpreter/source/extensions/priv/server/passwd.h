#ifndef _METERPRETER_SOURCE_EXTENSION_PRIV_PRIV_SERVER_PASSWD_H
#define _METERPRETER_SOURCE_EXTENSION_PRIV_PRIV_SERVER_PASSWD_H

DWORD request_passwd_get_sam_hashes(Remote *remote, Packet *packet);

#endif
