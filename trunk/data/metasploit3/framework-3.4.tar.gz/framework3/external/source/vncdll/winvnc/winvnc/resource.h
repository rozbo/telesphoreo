//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winvnc.rc
//
#define IDI_WINVNC                      102
#define IDD_PROPERTIES                  102
#define IDR_TRAYMENU                    104
#define IDR_VNCVIEWER_JAR               118
#define IDR_AUTHPANEL_CLASS             119
#define IDR_BLOCKCIPHER_CLASS           120
#define IDR_CIPHER_CLASS                121
#define IDR_CLIPBOARDFRAME_CLASS        122
#define IDR_CRYPTOUTILS_CLASS           123
#define IDR_IDEACIPHER_CLASS            124
#define IDR_OPTIONSFRAME_CLASS          125
#define IDR_RFBPROTO_CLASS              126
#define IDR_VNCCANVAS_CLASS             127
#define IDR_VNCVIEWER_CLASS             128
#define IDR_ANIMMEMIMAGESRC_CLASS       129
#define IDD_ABOUT                       131
#define IDB_VNCLOGO                     132
#define IDR_DESCIPHER_CLASS             133
#define IDI_FLASH                       134
#define IDD_OUTGOING_CONN               135
#define IDD_ACCEPT_CONN                 136
#define IDC_CONNECT_BORDER              1003
#define IDC_CONNECT_SOCK                1004
#define IDC_CONNECT_CORBA               1005
#define IDC_PORTNO_LABEL                1006
#define IDC_CONNECT_HTTP                1006
#define IDC_PASSWORD_LABEL              1007
#define IDC_PORTNO                      1008
#define IDC_PASSWORD                    1009
#define IDC_UPDATE_BORDER               1010
#define IDC_POLL_FULLSCREEN             1011
#define IDC_CONSOLE_ONLY                1012
#define IDC_POLL_FOREGROUND             1013
#define IDC_POLL_UNDER_CURSOR           1014
#define IDC_ONEVENT_ONLY                1015
#define IDC_VNCLOGO                     1016
#define IDC_CONNSETTINGS_BORDER         1016
#define IDC_VERSION                     1017
#define IDC_DISPLAY_NO_LABEL            1017
#define IDC_NAME                        1018
#define IDC_EMAIL                       1019
#define IDC_BUILDTEXT                   1019
#define IDC_VNC                         1020
#define IDC_ATT                         1021
#define IDC_BUILDTIME                   1021
#define IDC_WWW                         1022
#define IDC_COPYRIGHT                   1023
#define IDC_DISABLE_INPUTS              1024
#define IDC_APPLY                       1025
#define IDC_PORTNO_AUTO                 1026
#define IDC_HOSTNAME_EDIT               1027
#define IDC_DISABLE_LOCAL_INPUTS        1027
#define IDC_HOSTNAME_STATIC             1028
#define IDC_REMOVE_WALLPAPER            1028
#define IDC_NOTE_STATIC                 1029
#define IDACCEPT                        1030
#define IDREJECT                        1031
#define IDC_STATIC_TEXT1                1032
#define IDC_ACCEPT_IP                   1033
#define IDC_STATIC_TEXT                 1034
#define IDC_ACCEPT_TIMEOUT              1035
#define IDC_TRADEMARK                   1036
#define IDC_AUTO_DISPLAY_NO             1037
#define IDC_MANUAL_DISPLAY_NO           1038
#define IDC_DISPLAY_NUMBER              1039
#define IDC_LOCKSETTINGS                1040
#define IDC_LOCKSETTING_NOTHING         1041
#define IDC_LOCKSETTING_LOGOFF          1042
#define IDC_LOCKSETTING_LOCK            1043
#define ID_PROPERTIES                   40001
#define ID_CLOSE                        40002
#define ID_KILLCLIENTS                  40003
#define ID_ABOUT                        40004
#define ID_OUTGOING_CONN                40005
#define ID_DEFAULT_PROPERTIES           40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
