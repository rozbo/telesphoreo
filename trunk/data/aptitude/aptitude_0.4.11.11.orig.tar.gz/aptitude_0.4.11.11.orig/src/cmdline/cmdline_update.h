// cmdline_update.h                      -*-c++-*-
//
//  Copyright 2004 Daniel Burrows

#ifndef CMDLINE_UPDATE_H
#define CMDLINE_UPDATE_H

/** \file cmdline_update.h
 */

int cmdline_update(int argc, char *argv[], int verbose);

#endif // CMDLINE_UPDATE_H
