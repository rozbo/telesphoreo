// cmdline_download.h                    -*-c++-*-
//
//   Copyright 2004 Daniel Burrows

#ifndef CMDLINE_DOWNLOAD_H
#define CMDLINE_DOWNLOAD_H

/** \file cmdline_download.h
 */

int cmdline_download(int argc, char *argv[]);

#endif // CMDLINE_DOWNLOAD_H
