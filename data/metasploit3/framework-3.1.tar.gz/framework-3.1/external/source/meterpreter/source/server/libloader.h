#ifndef _METERPRETER_SOURCE_SERVER_LIBLOADER_H
#define _METERPRETER_SOURCE_SERVER_LIBLOADER_H

HMODULE libloader_load_library(LPCSTR name, PUCHAR buffer, DWORD bufferLength);

#endif
