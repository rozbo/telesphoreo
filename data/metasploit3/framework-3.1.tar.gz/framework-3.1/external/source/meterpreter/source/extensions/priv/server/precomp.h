#ifndef METERPRETER_SOURCE_EXTENSION_PRIV_SERVER_PRECOMP_H
#define METERPRETER_SOURCE_EXTENSION_PRIV_SERVER_PRECOMP_H

#define  _WIN32_WINNT 0x0400
#include "../priv.h"
#include "passwd.h"
#include "fs.h"

#define strcasecmp stricmp

#endif
