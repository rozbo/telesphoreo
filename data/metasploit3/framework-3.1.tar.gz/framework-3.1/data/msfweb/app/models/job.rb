class Job
  	def self.find_all()
		$msframework.jobs
	end
end
