class Session
  	def self.find_all()
		$msframework.sessions
	end
end
