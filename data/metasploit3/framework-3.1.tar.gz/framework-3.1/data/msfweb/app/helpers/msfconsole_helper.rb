module MsfconsoleHelper
end
