module NopsHelper
end
