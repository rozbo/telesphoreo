#!/usr/bin/env ruby

require 'test/unit'
require 'msf/base'

class Msf::Sessions::CommandShell::UnitTest < Test::Unit::TestCase
	def test_cmdshell
	end
end
