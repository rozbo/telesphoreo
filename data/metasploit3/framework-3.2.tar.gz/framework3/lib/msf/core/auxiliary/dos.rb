module Msf

###
#
# This module provides methods for Denial of Service attacks
#
###

module Auxiliary::Dos




end
end
