require 'msf/ui/gtk2/window/logs'
require 'msf/ui/gtk2/window/auxiliary'
require 'msf/ui/gtk2/window/consoles'
require 'msf/ui/gtk2/window/codeview'
