require 'msf/ui/gtk2/preferences/main.rb'
require 'msf/ui/gtk2/preferences/databases.rb'