require 'msf/ui/gtk2/meterpreter/stdapi/sys'
require 'msf/ui/gtk2/meterpreter/stdapi/fs'

