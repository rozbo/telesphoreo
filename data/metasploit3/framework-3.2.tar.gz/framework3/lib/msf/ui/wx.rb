module Msf
module Ui
module Wx

#
# The log source used by the web service.
#
LogSource = "msfwx"

end
end
end

require 'msf/ui/wx/driver'
