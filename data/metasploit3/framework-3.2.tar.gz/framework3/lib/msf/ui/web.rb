module Msf
module Ui
module Web

#
# The log source used by the web service.
#
LogSource = "msfweb"

end
end
end

require 'msf/ui/web/driver'