#!/usr/bin/env ruby

require 'rex/post/permission'
