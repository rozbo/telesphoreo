require 'rex/platforms/windows'
