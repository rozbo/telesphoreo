require 'rex/payloads/win32'
