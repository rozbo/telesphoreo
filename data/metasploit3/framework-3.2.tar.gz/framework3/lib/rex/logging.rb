#!/usr/bin/env ruby

require 'rex/constants' # for LEV_'s
require 'rex/logging/log_dispatcher'
