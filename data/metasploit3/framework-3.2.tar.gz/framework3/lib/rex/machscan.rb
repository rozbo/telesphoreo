#!/usr/bin/env ruby

module Rex
module MachScan

end
end

require 'rex/machscan/scanner'