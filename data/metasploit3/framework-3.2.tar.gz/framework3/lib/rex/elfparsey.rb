#!/usr/bin/env ruby

# $Id: elfparsey.rb 5413 2008-02-13 02:43:56Z ramon $

module Rex
module ElfParsey

end
end

require 'rex/elfparsey/elf'