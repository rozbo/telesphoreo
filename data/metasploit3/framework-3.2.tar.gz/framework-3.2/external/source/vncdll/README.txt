This project is a mangled version of RealVNC v3.3.7, it has been modified to work
as a payload with the DLL injection system developed by Jarkko Turkulainen and
Matt Miller. The majority of the changes were made by Matt Miller, with minor
tweaks and packaging by H D Moore. If you have questions about this source code
or would like to extend it, you should contact:

Matt Miller <mmiller[at]hick.org>
H D Moore <hdm[at]metasploit.com>

Updates to this project will be made available at metasploit.com