module IdeHelper
end
