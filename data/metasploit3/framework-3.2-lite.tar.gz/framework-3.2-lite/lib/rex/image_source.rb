#!/usr/bin/env ruby

# $Id: image_source.rb 5961 2008-11-19 07:22:26Z hdm $

module Rex
module ImageSource

end
end

require 'rex/image_source/disk'
require 'rex/image_source/memory'