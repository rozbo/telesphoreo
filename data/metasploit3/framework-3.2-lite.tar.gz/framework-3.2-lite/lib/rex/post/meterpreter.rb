#!/usr/bin/env ruby

require 'rex/post/meterpreter/client'
require 'rex/post/meterpreter/ui/console'