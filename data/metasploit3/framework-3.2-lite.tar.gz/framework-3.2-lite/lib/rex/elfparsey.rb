#!/usr/bin/env ruby

# $Id: elfparsey.rb 5961 2008-11-19 07:22:26Z hdm $

module Rex
module ElfParsey

end
end

require 'rex/elfparsey/elf'