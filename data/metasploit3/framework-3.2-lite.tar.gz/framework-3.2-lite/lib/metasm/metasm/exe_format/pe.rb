#    This file is part of Metasm, the Ruby assembly manipulation suite
#    Copyright (C) 2007 Yoann GUILLOT
#
#    Licence is LGPL, see LICENCE in the top-level directory


require 'metasm/exe_format/main'
require 'metasm/exe_format/mz'
require 'metasm/exe_format/coff_encode'
require 'metasm/exe_format/coff_decode'

module Metasm
class PE < COFF
	PESIG = "PE\0\0"

	attr_accessor :coff_offset, :signature, :mz

	def initialize(cpu=nil)
		super(cpu)
		@mz = MZ.new(cpu).share_namespace(self)
	end

	# overrides COFF#decode_header
	# simply sets the offset to the PE pointer before decoding the COFF header
	# also checks the PE signature
	def decode_header
		@cursection ||= self
		@encoded.ptr = 0x3c
		@encoded.ptr = decode_word
		@signature = @encoded.read(4)
		raise InvalidExeFormat, "Invalid PE signature #{@signature.inspect}" if @signature != PESIG
		@coff_offset = @encoded.ptr
		if @mz.encoded.empty?
			@mz.encoded << @encoded[0, @coff_offset-4]
			@mz.encoded.ptr = 0
			@mz.decode_header
		end
		super
	end

	# creates a default MZ file to be used in the PE header
	# this one is specially crafted to fit in the 0x3c bytes before the signature
	def encode_default_mz_header
		# XXX use single-quoted source, to avoid ruby interpretation of \r\n
		@mz.cpu = Ia32.new(386, 16)
		@mz.parse <<'EOMZSTUB'
	db "Needs Win32!\r\n$"
.entrypoint
	push cs
	pop  ds
	xor  dx, dx	  ; ds:dx = addr of $-terminated string
	mov  ah, 9        ; output string
	int  21h
	mov  ax, 4c01h    ; exit with code in al
	int  21h
EOMZSTUB
		@mz.assemble

		mzparts = @mz.pre_encode

		# put stuff before 0x3c
		@mz.encoded << mzparts.shift
		raise 'OH NOES !!1!!!1!' if @mz.encoded.virtsize > 0x3c	# MZ header is too long, cannot happen
		until mzparts.empty?
			break if mzparts.first.virtsize + @mz.encoded.virtsize > 0x3c
			@mz.encoded << mzparts.shift
		end

		# set PE signature pointer
		@mz.encoded.align 0x3c
		@mz.encoded << encode_word('pesigptr')

		# put last parts of the MZ program
		until mzparts.empty?
			@mz.encoded << mzparts.shift
		end

		# ensure the sig will be 8bytes-aligned
		@mz.encoded.align 8

		@mz.encoded.fixup 'pesigptr' => @mz.encoded.virtsize
		@mz.encoded.fixup @mz.encoded.binding
		@mz.encoded.fill
		@mz.encode_fix_checksum
	end

	# encodes the PE header before the COFF header, uses a default mz header if none defined
	# the MZ header must have 0x3c pointing just past its last byte which should be 8bytes aligned
	# the 2 1st bytes of the MZ header should be 'MZ'
	def encode_header(*a)
		encode_default_mz_header if @mz.encoded.empty?

		@encoded << @mz.encoded.dup

		# append the PE signature
		@signature ||= PESIG
		@encoded << @signature

		super
	end

	# a returns a new PE with only minimal information copied:
	#  section name/perm/addr/content
	#  exports
	#  imports (with boundimport cleared)
	#  resources
	def mini_copy(share_ns=true)
		ret = self.class.new(@cpu)
		ret.share_namespace(self) if share_ns
		ret.header.machine = @header.machine
		ret.optheader.entrypoint = @optheader.entrypoint
		ret.optheader.image_base = @optheader.image_base
		@sections.each { |s|
			rs = Section.new
			rs.name = s.name
			rs.virtaddr = s.virtaddr
			rs.characteristics = s.characteristics
			rs.encoded = s.encoded
			ret.sections << s
		}
		ret.resource = resource
		ret.tls = tls
		if imports
			ret.imports = @imports.map { |id| id.dup }
			ret.imports.each { |id|
				id.timestamp = id.firstforwarder =
				id.ilt_p = id.libname_p = nil
			}
		end
		ret.export = export
		ret
	end

	def c_set_default_entrypoint
		return if @optheader.entrypoint
		if @sections.find { |s| s.encoded.export['main'] }
			@optheader.entrypoint = 'main'
		elsif @sections.find { |s| s.encoded.export['DllEntryPoint'] }
			@optheader.entrypoint = 'DllEntryPoint'
		elsif @sections.find { |s| s.encoded.export['DllMain'] }
			cp = @cpu.new_cparser
			cp.parse <<EOS
enum { DLL_PROCESS_DETACH, DLL_PROCESS_ATTACH, DLL_THREAD_ATTACH, DLL_THREAD_DETACH, DLL_PROCESS_VERIFIER };
__stdcall int DllMain(void *handle, unsigned long reason, void *reserved);
__stdcall int DllEntryPoint(void *handle, unsigned long reason, void *reserved) {
	int ret = DllMain(handle, reason, reserved);
	if (ret == 0 && reason == DLL_PROCESS_ATTACH)
		DllMain(handle, DLL_PROCESS_DETACH, reserved);
	return ret;
}
EOS
			parse(@cpu.new_ccompiler(cp, self).compile)
			assemble
			@optheader.entrypoint = 'DllEntryPoint'
		elsif @sections.find { |s| s.encoded.export['WinMain'] }
			cp = @cpu.new_cparser
			cp.parse <<EOS
#define GetCommandLine GetCommandLineA
#define GetModuleHandle GetModuleHandleA
#define GetStartupInfo GetStartupInfoA
#define STARTF_USESHOWWINDOW 0x00000001
#define SW_SHOWDEFAULT 10

typedef unsigned long DWORD;
typedef unsigned short WORD;
typedef struct {
        DWORD cb; char *lpReserved, *lpDesktop, *lpTitle;
        DWORD dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
	WORD wShowWindow, cbReserved2; char *lpReserved2;
        void *hStdInput, *hStdOutput, *hStdError;
} STARTUPINFO;

__stdcall void *GetModuleHandleA(const char *lpModuleName);
__stdcall void GetStartupInfoA(STARTUPINFO *lpStartupInfo);
__stdcall void ExitProcess(unsigned int uExitCode);
__stdcall char *GetCommandLineA(void);
__stdcall int WinMain(void *hInstance, void *hPrevInstance, char *lpCmdLine, int nShowCmd);

int main(void) {
	STARTUPINFO startupinfo;
	startupinfo.cb = sizeof(STARTUPINFO);
	char *cmd = GetCommandLine();
	int ret;

	if (*cmd == '"') {
		cmd++;
		while (*cmd && *cmd != '"') {
			if (*cmd == '\\\\') cmd++;
			cmd++;
		}
		if (*cmd == '"') cmd++;
	} else
		while (*cmd && *cmd != ' ') cmd++;
	while (*cmd == ' ') cmd++;

	GetStartupInfo(&startupinfo);
	ret = WinMain(GetModuleHandle(0), 0, cmd, (startupinfo.dwFlags & STARTF_USESHOWWINDOW) ? (int)startupinfo.wShowWindow : (int)SW_SHOWDEFAULT);
	ExitProcess((DWORD)ret);
	return ret;
}
EOS
			parse(@cpu.new_ccompiler(cp, self).compile)
			assemble
			@optheader.entrypoint = 'main'
		end
	end

	# handles writes to fs:[0] -> dasm SEH handler (first only, does not follow the chain)
	# TODO seh prototype (args => context)
	# TODO hook on (non)resolution of :w xref
	def get_xrefs_x(dasm, di)
		if @cpu.kind_of? Ia32 and a = di.instruction.args.first and a.kind_of? Ia32::ModRM and a.seg and a.seg.val == 4 and
				w = get_xrefs_rw(dasm, di).find { |type, ptr, len| type == :w and ptr.externals.include? 'segment_base_fs' } and
				dasm.backtrace(Expression[w[1], :-, 'segment_base_fs'], di.address) == [Expression[0]]
			sehptr = w[1]
			sz = @cpu.size/8
			sehptr = Indirection.new(Expression[Indirection.new(sehptr, sz, di.address), :+, sz], sz, di.address)
			a = dasm.backtrace(sehptr, di.address, :include_start => true, :origin => di.address, :type => :x, :detached => true)
			puts "backtrace seh from #{di} => #{a.map { |addr| Expression[addr] }.join(', ')}" if $VERBOSE
			a.each { |aa|
				next if aa == Expression::Unknown
				l = dasm.auto_label_at(aa, 'seh', 'loc', 'sub')
				dasm.addrs_todo << [aa] 
			}
			super
		else
			super
		end
	end

	# returns a disassembler with a special decodedfunction for GetProcAddress (i386 only), and the default func
	def init_disassembler
		d = super
		d.backtrace_maxblocks_data = 4
		if @cpu.kind_of? Ia32
			old_cp = d.c_parser
			d.c_parser = nil
			d.parse_c '__stdcall void *GetProcAddress(int, char *);'
			gpa = @cpu.decode_c_function_prototype(d.c_parser, 'GetProcAddress')
			d.c_parser = old_cp
			@getprocaddr_unknown = []
			gpa.btbind_callback = proc { |dasm, bind, funcaddr, calladdr, expr, origin, maxdepth|
				break bind if @getprocaddr_unknown.include? [dasm, calladdr] or not Expression[expr].externals.include? :eax
				sz = @cpu.size/8
				break bind if not dasm.decoded[calladdr]
				fnaddr = dasm.backtrace(Indirection.new(Expression[:esp, :+, 2*sz], sz, calladdr), calladdr, :include_start => true, :maxdepth => maxdepth)
				if fnaddr.kind_of? ::Array and fnaddr.length == 1 and s = dasm.get_section_at(fnaddr.first) and fn = s[0].read(64) and i = fn.index(0) and i > sz	# try to avoid ordinals
					bind = bind.merge :eax => Expression[fn[0, i]]
				else
					@getprocaddr_unknown << [dasm, calladdr]
					puts "unknown func name for getprocaddress from #{Expression[calladdr]}" if $VERBOSE
				end
				bind
			}
			d.function[Expression['GetProcAddress']] = gpa
			d.function[:default] = @cpu.disassembler_default_func
		end
		d
	end
end

# an instance of a PE file, loaded in memory
# just change the rva_to_off and the section content decoding methods
class LoadedPE < PE
	attr_accessor :load_address

	# use the virtualaddr/virtualsize fields of the section header
	def decode_section_body(s)
		s.encoded = @encoded[s.virtaddr, s.virtsize]
	end

	# reads a loaded PE from memory, returns a PE object
	# dumps the header, optheader and all sections ; try to rebuild IAT (#memdump_imports)
	def self.memdump(memory, baseaddr, entrypoint = nil)
		loaded = LoadedPE.load memory[baseaddr, 0x1000_0000]
		loaded.load_address = baseaddr
		loaded.decode

		dump = PE.new(loaded.cpu_from_headers)
		dump.share_namespace loaded
		dump.optheader.image_base = baseaddr
		dump.optheader.entrypoint = (entrypoint || loaded.optheader.entrypoint + baseaddr) - baseaddr
		dump.directory['resource_table'] = loaded.directory['resource_table']

		loaded.sections.each { |s|
			ss = Section.new
			ss.name = s.name
			ss.virtaddr = s.virtaddr
			ss.encoded = s.encoded
			ss.characteristics = s.characteristics
			dump.sections << ss
		}

		loaded.memdump_imports(memory, dump)

		dump
	end

	# rebuilds an IAT from the loaded pe and the memory
	# for each loaded iat, find the matching dll in memory
	# for each loaded iat entry, retrieve the exported name from the loaded dll
	# then build the dump iat
	# scans page by page backward from the first iat address for the loaded dll (must not be forwarded)
	# TODO bound imports
	def memdump_imports(memory, dump)
		dump.imports ||= []
		@imports.each { |id|
			next if not id.iat or not id.iat.first
			addr = id.iat.first & ~0xffff
			256.times { break if memory[addr, 2] == 'MZ' ; addr -= 0x10000 }
			next if memory[addr, 2] != 'MZ'
			loaded_dll = LoadedPE.load memory[addr, 0x1000_0000]
			loaded_dll.load_address = addr
			loaded_dll.decode_header
			loaded_dll.decode_exports
			next if not loaded_dll.export

			dump_id = ImportDirectory.new
			dump_id.libname = loaded_dll.export.libname
			dump_id.imports = []
			dump_id.iat_p = id.iat_p

			id.iat.each { |ptr|
				if not e = loaded_dll.export.exports.find { |e| e.target == ptr - loaded_dll.load_address }
					# check for forwarder
					# XXX won't handle forwarder to forwarder
					addr = ptr & ~0xffff
					256.times { break if memory[addr, 2] == 'MZ' ; addr -= 0x10000 }
					if memory[addr, 2] == 'MZ'
						f_dll = LoadedPE.load memory[addr, 0x1000_0000]
						f_dll.decode_header ; f_dll.decode_exports
						if f_dll.export and ee = f_dll.export.exports.find { |ee| ee.target == ptr - addr }
							e = loaded_dll.export.exports.find { |e| e.forwarder_name == ee.name }
						end
					end
					if not e
						dump_id = nil
						break
					end
				end
				dump_id.imports << ImportDirectory::Import.new
				if e.name
					dump_id.imports.last.name = e.name
				else
					dump_id.imports.last.ordinal = e.ordinal
				end
			}

			dump.imports << dump_id if dump_id
		} if @imports
	end
end
end