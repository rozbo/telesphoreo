module Msf
module Simple

###
#
# A simplified encoder wrapper.  Currently there is no simplification
# required.  This is here because stuff is there.
#
###
module Encoder
	include Module
end

end
end