
module Ole # :nodoc:
	require 'ole/support'
	Log = Logger.new_with_callstack
end