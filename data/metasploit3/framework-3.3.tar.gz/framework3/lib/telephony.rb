require 'serialport'

module Telephony
end

require 'telephony/modem'

