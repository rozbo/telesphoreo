#!/usr/bin/env ruby

require 'rex/test'
require 'rex/proto/dcerpc/uuid.rb.ut'
require 'rex/proto/dcerpc/response.rb.ut'
require 'rex/proto/dcerpc/packet.rb.ut'
# require 'rex/proto/dcerpc/ndr.rb.ut'
require 'rex/proto/dcerpc/handle.rb.ut'
require 'rex/proto/dcerpc/client.rb.ut'