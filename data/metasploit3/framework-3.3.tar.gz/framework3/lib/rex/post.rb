#!/usr/bin/env ruby

# General independent containers
require 'rex/post/permission'

# Post-exploitation clients
require 'rex/post/dispatch_ninja'
require 'rex/post/meterpreter'