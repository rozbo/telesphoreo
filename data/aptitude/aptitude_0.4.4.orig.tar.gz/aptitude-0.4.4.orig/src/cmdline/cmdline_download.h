// cmdline_download.h                    -*-c++-*-
//
//   Copyright 2004 Daniel Burrows

#ifndef CMDLINE_DOWNLOAD_H
#define CMDLINE_DOWNLOAD_H

int cmdline_download(int argc, char *argv[]);

#endif // CMDLINE_DOWNLOAD_H
