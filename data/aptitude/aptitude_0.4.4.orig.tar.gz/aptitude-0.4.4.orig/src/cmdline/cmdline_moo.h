// cmdline_moo.h                   -*-c++-*-
//
//   Copyright 2004 Daniel Burrows
//
// The most important command-line action.

#ifndef CMDLINE_MOO
#define CMDLINE_MOO

int cmdline_moo(int argc, char *argv[], int verbose);

#endif // CMDLINE_MOO
