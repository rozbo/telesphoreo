// cmdline_update.h                      -*-c++-*-
//
//  Copyright 2004 Daniel Burrows

#ifndef CMDLINE_UPDATE_H
#define CMDLINE_UPDATE_H

int cmdline_update(int argc, char *argv[]);

#endif // CMDLINE_UPDATE_H
