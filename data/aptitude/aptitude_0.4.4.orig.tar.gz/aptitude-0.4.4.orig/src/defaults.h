// defaults.h
//
//  Copyright 1999 Daniel Burrows
//
//  Populates the Aptitude configuration with defaults for a bunch of stuff

#ifndef DEFAULTS_H
#define DEFAULT_H

void init_defaults();

#endif
