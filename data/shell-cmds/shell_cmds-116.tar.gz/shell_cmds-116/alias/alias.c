
/* This file is a dummy file to make the Makefile to work correctly to install
   the shell scripts. It does not lead to any deliverable. Do not remove this
   file from this (..../shell_cmds/alias) directory.
*/
int main()
{
  exit(0);
}

