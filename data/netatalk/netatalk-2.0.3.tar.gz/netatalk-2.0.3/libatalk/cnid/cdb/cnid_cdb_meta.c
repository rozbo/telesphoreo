/*
 * $Id: cnid_cdb_meta.c,v 1.1.4.1 2003/09/09 16:42:21 didg Exp $
 *
 * Copyright (c) 1999. Adrian Sun (asun@zoology.washington.edu)
 * All Rights Reserved. See COPYRIGHT.
 *
 * deal with metadata
 *
 */
