/*
 * $Id: session.h,v 1.2 2001/06/25 20:13:45 rufustfirefly Exp $
 */

#ifndef PAPD_SESSION_H
#define PAPD_SESSION_H 1

#include <atalk/atp.h>

int session( ATP atp, struct sockaddr_at *sat );

#endif /* PAPD_SESSION_H */
